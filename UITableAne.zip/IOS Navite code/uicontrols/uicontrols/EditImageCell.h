//
//  EditImageCell.h
//  uicontrols
//
//  Created by Gs on 02/06/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditImageCell : UITableViewCell
@property (nonatomic, strong) NSDictionary *jcellData;
@property (nonatomic, strong) UIImageView *imgView;
- (void) setData:(NSDictionary *)jcellData;
@end
