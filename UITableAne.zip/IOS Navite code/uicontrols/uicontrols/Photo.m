//
//  Photo.m
//  uicontrols
//
//  Created by Gs on 27/05/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "Photo.h"

@implementation Photo

@end
