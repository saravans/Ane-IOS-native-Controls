//
//  TableViewController.m
//  uicontrols
//
//  Created by Gs on 26/05/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "TableViewController.h"
#import "EditCell.h"
#import "EditImageCell.h"
#import "FooterView.h"

@interface TableViewController ()

@end

@implementation TableViewController


NSMutableArray *data  = nil;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
     if (self) {
         NSMutableArray *slide;
         
         data = [[NSMutableArray alloc]init];
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [data addObject:slide];
         slide = [[NSMutableArray alloc]init];

         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         
         [data addObject:slide];
         slide = [[NSMutableArray alloc]init];

         
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];

         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
          [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
          [data addObject:slide];
       
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
          [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         
         [data addObject:slide];
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];

         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"stext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"itext", @"type", nil]];
         [data addObject:slide];
         
         slide = [[NSMutableArray alloc]init];
         [slide addObject:[[NSDictionary alloc] initWithObjectsAndKeys:@"text", @"type", nil]];
         [data addObject:slide];

        [self drawLayout];
         NSLog(@"SLEF");
     }
    return self;
}


-(void)drawLayout{
    imageTableView = [[UITableView alloc]initWithFrame:CGRectMake(10, 0, 298, 420)];
    imageTableView.delegate = self;
    imageTableView.dataSource = self;
    [self addSubview:imageTableView];
    [imageTableView registerClass:[EditCell class] forCellReuseIdentifier:@"samplecell"];
    [imageTableView registerClass:[EditImageCell class] forCellReuseIdentifier:@"sampleimgcell"];
    [imageTableView setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
    [self setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
    imageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [imageTableView reloadData];
    NSLog(@"DRAWLAYOUT");
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    FooterView* customView = [[FooterView alloc] initWithFrame:CGRectMake(0, -4, 300, 40)];
     return customView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if(section==0 || (data.count-1) == section )
    return 0.0;
    else    return 45.0;

}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *type = [[[data objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]objectForKey:@"type"];

    if ([type  isEqual: @"itext"] )
        return 140.0;
    else
        return 80.0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return data.count;
}

- (NSInteger)tableView:(UITableView *)tableView  numberOfRowsInSection:(NSInteger)section {
     return [[data objectAtIndex:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *dictData =[[data objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    NSString *type = [dictData objectForKey:@"type"];

    if ([ type isEqual: @"text"] ){
        EditCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"samplecell" forIndexPath:indexPath];
        if (cell == nil)
            cell = [[EditCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"samplecell"];
        cell.txtTitle.text =[NSString stringWithFormat:@"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC %d",indexPath.row ];
        [cell setData:dictData];
        [cell setFrame:CGRectMake(cell.frame.origin.x, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height)];

        return cell;
    }else if ([type  isEqual: @"itext"] ){
         EditImageCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"sampleimgcell" forIndexPath:indexPath];
        if (cell == nil)
            cell = [[EditImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"sampleimgcell"];
         [cell setData:dictData];
        [cell setFrame:CGRectMake(cell.frame.origin.x, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height)];

        return cell;
    }else {
        EditCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"samplecell" forIndexPath:indexPath];
        if (cell == nil)
            cell = [[EditCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"samplecell"];
        cell.txtTitle.text =[NSString stringWithFormat:@"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years index:"];
         [cell setData:dictData];
        [cell setFrame:CGRectMake(cell.frame.origin.x, cell.frame.origin.y, cell.frame.size.width, cell.frame.size.height)];
        return cell;
    }
}


@end
