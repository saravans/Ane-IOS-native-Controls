//
//  EditCell.h
//  uicontrols
//
//  Created by Gs on 02/06/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EditCell : UITableViewCell<UITextFieldDelegate,UITextViewDelegate>
@property (nonatomic, strong) UITextView *txtTitle;
@property (nonatomic, strong) NSDictionary *jcellData;
 - (void) setData:(NSDictionary *)jcellData;
@end
