//
//  FooterView.m
//  Sample
//
//  Created by Gs on 03/06/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "FooterView.h"

@implementation FooterView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self drawLayout];
     }
    return self;
}

-(void)drawLayout{
    self.backgroundColor = [UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1];
    
    UIButton *btnLike = [UIButton buttonWithType:UIButtonTypeCustom];
    btnLike.frame = CGRectMake(self.frame.size.width-70,5, 60,30);
    [btnLike setImage:[UIImage imageNamed:@"ico_atn_accept"] forState:UIControlStateNormal];
    [self addSubview:btnLike];
      [btnLike setBackgroundColor:[UIColor whiteColor]  ];
     UIButton *btnComment = [UIButton buttonWithType:UIButtonTypeCustom];
     btnComment.frame = CGRectMake(self.frame.size.width-140, 5, 60, 30);
    btnComment.backgroundColor = [UIColor whiteColor];
     [self addSubview:btnComment];
    btnComment.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [btnComment setImage:[UIImage imageNamed:@"ico_atn_like"] forState:UIControlStateNormal];
}

@end
