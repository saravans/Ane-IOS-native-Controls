//
//  EditImageCell.m
//  uicontrols
//
//  Created by Gs on 02/06/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "EditImageCell.h"

@implementation EditImageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];

        self.imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0,10, self.frame.size.width ,self.frame.size.height-10)];
        [self addSubview:self.imgView];
        [self.imgView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
        [self.imgView setContentMode:UIViewContentModeScaleAspectFit];
        [self.imgView setBackgroundColor:[UIColor whiteColor]];
        [[self.imgView layer] setBorderColor:[[UIColor colorWithRed:0.89 green:0.89 blue:0.89 alpha:1] CGColor]];
        [[self.imgView layer] setBorderWidth:1];

    }
    
    return self;
}

-(void)setData:(NSDictionary *)jcellData{    
    self.imgView.image = [UIImage imageNamed:@"g.png"];
    [[self.imgView layer] setBorderColor:[[UIColor colorWithRed:0.89 green:0.89 blue:0.89 alpha:1] CGColor]];
    [[self.imgView layer] setBorderWidth:1];

}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
