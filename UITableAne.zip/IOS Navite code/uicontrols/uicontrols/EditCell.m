//
//  EditCell.m
//  uicontrols
//
//  Created by Gs on 02/06/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "EditCell.h"

@implementation EditCell
@synthesize jcellData = _jcellData;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
        self.txtTitle = [[UITextView alloc] initWithFrame:CGRectMake(0,5, self.frame.size.width, 75)];
        [self addSubview:self.txtTitle];
        self.txtTitle.delegate = self;
        self.txtTitle.returnKeyType = UIReturnKeyDone;
        [self.txtTitle setBackgroundColor:[UIColor whiteColor]];
        [[self.txtTitle layer] setBorderColor:[[UIColor colorWithRed:0.89 green:0.89 blue:0.89 alpha:1] CGColor]];
        [[self.txtTitle layer] setBorderWidth:1];
      }
    return self;
}

-(void)setData:(NSDictionary *)jcellData{
    _jcellData = jcellData;
    NSString *type = [_jcellData objectForKey:@"type"];
    
    if ([ type isEqual: @"text"] ){
        self.txtTitle.font =  [UIFont fontWithName:@"Helvetica" size:14.0];
    }else{
        self.txtTitle.font =  [UIFont fontWithName:@"Helvetica-Light" size:14.0];
    }

 }

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"enter");
    if([textField.text isEqualToString:@"\n"]) {
        [textField resignFirstResponder];
        NSLog(@"enter done");
        return NO;
    }
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSLog(@"enter");
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
         NSLog(@"enter done");
        return NO;
    }
    return YES;
}

@end
