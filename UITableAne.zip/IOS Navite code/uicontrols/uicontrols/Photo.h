//
//  Photo.h
//  uicontrols
//
//  Created by Gs on 27/05/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Photo : NSObject
@property (nonatomic, strong) NSURL *photoUrl; // To store the URL of the image
@property (nonatomic, strong) UIImage *image; // To store the actual image

@end
