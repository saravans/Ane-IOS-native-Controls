//
//  uicontrols.m
//  uicontrols
//
//  Created by Gs on 26/05/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import "uicontrols.h"
#include "FlashRuntimeExtensions.h"
#import "TableViewController.h"

FREObject appCtx = NULL;
void *_self;
uicontrols* refToSelf;
UIView *viewF;

@implementation uicontrols
@synthesize applicationView = _applicationView;
- (id) init
{
    if (self)
    {
        _self = (__bridge  void *)(self);
    }
    return self;
}


FREObject createControls(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
{
    if(table==nil)
    {
        table = [[TableViewController alloc]initWithFrame:CGRectMake(0,40,320,440)];
        [refToSelf.applicationView addSubview:table];
        [refToSelf.applicationView setFrame:CGRectMake(0,0,320,480)];
    }
    return NULL;
}


FREObject clearControls(FREContext ctx, void* funcData, uint32_t argc, FREObject argv[])
{
    if(table!=nil)
        [table removeFromSuperview];
    table = nil;
    return NULL;
}


FREContext _ctx;
TableViewController *table = nil;

void ContextControlInitializer(void* extData, const uint8_t* ctxType, FREContext ctx, uint32_t* numFunctionsToTest, const FRENamedFunction** functionsToSet) {
    _ctx = ctx;
    *numFunctionsToTest = 2;
    FRENamedFunction* func = (FRENamedFunction*)malloc(sizeof(FRENamedFunction)*2);
    
    func[0].name = (const uint8_t*)"createControls";
    func[0].functionData = NULL;
    func[0].function = &createControls;
    
    func[1].name = (const uint8_t*)"clearControls";
    func[1].functionData = NULL;
    func[1].function = &clearControls;
    
    *functionsToSet = func;
    
    appCtx = ctx;
    
    uicontrols * t = [[uicontrols alloc] init];
    refToSelf = t;
    [refToSelf setApplicationView:[[[[UIApplication sharedApplication] windows] objectAtIndex:0] rootViewController].view];
    [refToSelf.applicationView setBackgroundColor:[UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1]];
}


// A native context instance is disposed
void ContextControlFinalizer(FREContext ctx) {
    return;
}

// Initialization function of each extension
void ExtControlInitializer(void** extDataToSet, FREContextInitializer* ctxInitializerToSet, FREContextFinalizer* ctxFinalizerToSet) {
    *extDataToSet = NULL;
    *ctxInitializerToSet = &ContextControlInitializer;
    *ctxFinalizerToSet = &ContextControlFinalizer;
}

// Called when extension is unloaded
void ExtControlFinalizer(void* extData) {
    return;
}

@end
