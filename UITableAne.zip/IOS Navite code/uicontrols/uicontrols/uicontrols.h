//
//  uicontrols.h
//  uicontrols
//
//  Created by Gs on 26/05/14.
//  Copyright (c) 2014 Gs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface uicontrols : NSObject{
UIView *applicationView;
}
 @property(retain, readwrite, nonatomic) UIView *applicationView;
@end
